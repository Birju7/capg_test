/**
 * 
 */
package com.cg.lab3.dao;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.lab3.exception.AuthorException;
import com.cg.lab3.model.Author;
import com.cg.lab3.model.Book;
import com.cg.lab3.util.DBUtil;


public class AuthorDao implements IAuthorDao {
	//prep -work 1- Connection
	private static Connection connection;
	private PreparedStatement ps;
	private Statement st;
	private ResultSet rs;
	private static Logger myLogger;
     static{   	
   	  Properties props = System.getProperties();
   	  String userDir= props.getProperty("user.dir")+"/src/main/resources/";
   	  System.out.println("Current working directory is " +userDir);
   	  
   	  PropertyConfigurator.configure(userDir+"log4j.properties");
 		myLogger=Logger.getLogger("DBUtil.class");
 		}
	static {
		try {
			connection= DBUtil.getConnection();
			myLogger.info("connection Obtained!!");
		} catch (AuthorException e) {
			myLogger.error("Connection Not Obtained at authorDao : "+e);
			//System.out.print("Connection Not Obtained at authorDao");
		}
	}
	

	/* (non-Javadoc)
	 * @see com.cg.lab3.dao.IauthorDao#addauthor(com.cg.jdbc.ems.model.author)
	 */
	@Override
	public Author addAuthor(Author author)throws AuthorException{
		String sql ="insert into author(author_fname,author_mname, author_lname, author_phone) values(?,?,?,?)";		
		try {
		//step1 : obtain psz
			ps= connection.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
		//step 2: set the ps placeholder values
			ps.setString(1, author.getFirstName());
			ps.setString(2, author.getMiddleName());	
			ps.setString(3, author.getLastName());
			ps.setLong(4, author.getPhoneNo().longValue());
		//step 3: execute Query (for DML we have executeUpdate method )
			int noOfRec = ps.executeUpdate();
		//getting the auto-generated value
			BigInteger generatedId = BigInteger.valueOf(0L);
			rs = ps.getGeneratedKeys();
			if (rs.next()) {
				generatedId = BigInteger.valueOf(rs.getLong(1));
				myLogger.info("Auto generated Id " + generatedId);
			}
		//setting the auto-generated Id to current emp obj
			author.setAuthorId(generatedId);
		} catch (SQLException e) {
			myLogger.error(" Error at addauthor Dao method : "+e);
			throw new AuthorException(" Error at addauthor Dao method : "+e);
		}finally {
			if(ps!=null) {
				try {
					ps.close();
				} catch (SQLException e) {
					System.out.println(" Error at addauthor Dao method : "+e);
				}
			}
		}
		return author;
	}

	/* (non-Javadoc)
	 * @see com.cg.lab3.dao.IauthorDao#listAllauthors()
	 */
	@Override
	public List<Author> listAllAuthors()throws AuthorException{
		String sql ="select * from author";
		List<Author> authList = new ArrayList<Author>();	
		try {
			ps= connection.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
			//for select queries we have executeQuery method which returns ResultSet
			rs= ps.executeQuery();
			while (rs.next()) {
				//create author obj
				Author auth = new Author();
				//get the value from rs and set to emp obj
				auth.setAuthorId(BigInteger.valueOf(rs.getLong(1)));
				auth.setFirstName(rs.getString("author_fname"));
				auth.setMiddleName(rs.getString("author_mname"));
				auth.setLastName(rs.getString("author_lname"));
				auth.setPhoneNo(rs.getBigDecimal("author_phone").toBigInteger());			
				//add the emp obj to empList
				authList.add(auth);
				
			}
		} catch (SQLException e) {
			System.out.println(" Error at addauthor Dao method : "+e);
		}finally {
			if(ps!=null) {
				try {
					ps.close();
				} catch (SQLException e) {
					System.out.println(" Error at addauthor Dao method : "+e);
				}
			}
		}
		return authList;
	}

	@Override
	public int updateAuthor(Author author)throws AuthorException {
		String sql ="update author set author_fname=? , author_mname=? ,author_lname = ?, author_phone = ? where author_id=?";
		//String sql ="update author set author_fname=? author_name AND emp_sal=?  where emp_id=?";
		int noOfRec=0;
		try {
			System.out.println("Updated"+author);
			//transaction boundary starts
			connection.setAutoCommit(false);//enabling the transaction
			ps=connection.prepareStatement(sql);
			ps.setString(1, author.getFirstName());
			ps.setString(2, author.getMiddleName());	
			ps.setString(3, author.getLastName());
			ps.setLong(4, author.getPhoneNo().longValue());
			ps.setLong(5, author.getAuthorId().longValue());
			
			noOfRec=ps.executeUpdate();
			
			connection.commit();
		}catch (SQLException e) {
			e.printStackTrace();
			System.out.println(" Error at updateauthor Dao method : "+e);
			try {
				connection.rollback();
			} catch (SQLException e1) {
				System.out.println(" Error at updateauthor Dao method : "+e);
			}//rollback the tx to the last commit.
		}finally {
			if(ps!=null) {
				try {
					ps.close();
				} catch (SQLException e) {
					System.out.println(" Error at updateauthor Dao method : "+e);
				}
			}
		}
		return noOfRec;
	}

	@Override
	public int deleteAuthor(BigInteger authorId)throws AuthorException {
		String sql ="delete from author where author_id=?";
		int noOfRec=0;
		try {
			ps=connection.prepareStatement(sql);
			ps.setLong(1, authorId.longValue());
			
			noOfRec=ps.executeUpdate();
		}catch (SQLException e) {
			System.out.println(" Error at delete author Dao method : "+e);
		}finally {
			if(ps!=null) {
				try {
					ps.close();
				} catch (SQLException e) {
					System.out.println(" Error at delete author Dao method : "+e);
				}
			}
		}
		return noOfRec;
	}


	

	@Override
	public List<Book> listAllBooks() throws AuthorException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public int updateBook(Book book) throws AuthorException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deleteBook(BigInteger isbn) throws AuthorException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public Book addBook(Book book) throws AuthorException {
		String sql ="insert into book(author_fname,author_mname, author_lname, author_phone) values(?,?,?,?)";		
		try {
		//step1 : obtain psz
			ps= connection.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
		//step 2: set the ps placeholder values
			ps.setString(1, author.getFirstName());
			ps.setString(2, author.getMiddleName());	
			ps.setString(3, author.getLastName());
			ps.setLong(4, author.getPhoneNo().longValue());
		//step 3: execute Query (for DML we have executeUpdate method )
			int noOfRec = ps.executeUpdate();
		//getting the auto-generated value
			BigInteger generatedId = BigInteger.valueOf(0L);
			rs = ps.getGeneratedKeys();
			if (rs.next()) {
				generatedId = BigInteger.valueOf(rs.getLong(1));
				myLogger.info("Auto generated Id " + generatedId);
			}
		//setting the auto-generated Id to current emp obj
			author.setAuthorId(generatedId);
		} catch (SQLException e) {
			myLogger.error(" Error at addauthor Dao method : "+e);
			throw new AuthorException(" Error at addauthor Dao method : "+e);
		}finally {
			if(ps!=null) {
				try {
					ps.close();
				} catch (SQLException e) {
					System.out.println(" Error at addauthor Dao method : "+e);
				}
			}
		}
		return author;;
	}

}


