
package com.cg.lab3.dao;

import java.math.BigInteger;
import java.util.List;
import com.cg.lab3.exception.AuthorException;
import com.cg.lab3.model.Author;
import com.cg.lab3.model.Book;

/**
 * @author rvikash
 *
 */
public interface IAuthorDao {
	public Author addAuthor(Author author)throws AuthorException;
	public List<Author> listAllAuthors()throws AuthorException;
	public int updateAuthor(Author author)throws AuthorException;
	public int deleteAuthor(BigInteger authorId)throws AuthorException;
	
	
	public Book addBook(Book book)throws AuthorException;
	public List<Book> listAllBooks()throws AuthorException;
	public int updateBook(Book book)throws AuthorException;
	public int deleteBook(BigInteger isbn)throws AuthorException;

}
