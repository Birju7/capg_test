/**
 * 
 */
package com.cg.lab3.client;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;
import java.util.Scanner;

import com.cg.lab3.dao.AuthorDao;
import com.cg.lab3.dao.IAuthorDao;
import com.cg.lab3.exception.AuthorException;
import com.cg.lab3.model.Author;
import com.cg.lab3.model.Book;

public class Lab3Client {
	// obj of Dao
	private static IAuthorDao authorDao;
	static {
		authorDao= new AuthorDao();
	}

	public static void main(String[] args) throws AuthorException {
		Author author = new Author();
		Book book = new Book();
		
		author.setFirstName("A");;
		author.setMiddleName("V");
		author.setLastName("c");
		author.setPhoneNo(BigInteger.valueOf(123456789));
		
		book.setBook_author(BigInteger.valueOf(123456789));
		book.setPrice(BigDecimal.valueOf(12.3456789));
		book.setTitle("Myths of java by Ajay");
		
		
		
		
		
//adding the emp obj by calling dao layer method
		author = authorDao.addAuthor(author);
		if(author!= null) System.out.println("author Added successfully :"+author);
		else System.out.println("author NOT Added :"+author);
		
		book = authorDao.addBook(book);
		if(book!= null) System.out.println("book Added successfully :"+book);
		else System.out.println("book NOT Added :"+book);
		
//listing all emp obj by calling dao layer method
		List<Author> authList = authorDao.listAllAuthors();
		if(authList!= null)
			authList.forEach(System.out::println);
		else {
			System.out.println("No Record Found!!");
		}
		
		List<Book> bookList = authorDao.listAllBooks();
		if(bookList!= null)
			bookList.forEach(System.out::println);
		else {
			System.out.println("No Record Found!!");
		}
//updating the emp obj by calling dao layer method
		author.setFirstName("F");;
		author.setMiddleName("B");
		author.setLastName("c");
		int noOfRecUp = authorDao.updateAuthor(author);
		if(noOfRecUp> 0) System.out.println("author Updated successfully :"+author);
		else System.out.println("author NOT Updated");
		
//		update the price of the books for which the author has been entered. But why?
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the author id for which the book price has to be updated");
		book.setBook_author(BigInteger.valueOf(sc.nextInt()));
		noOfRecUp = authorDao.updateBook(book);
		if(noOfRecUp> 0) System.out.println("author Updated successfully :"+author);
		else System.out.println("author NOT Updated");
		
//finding the emp obj by calling dao layer method
//			author = authorDao.findByEmpId(author.getEmpId());
//			if(author!= null) System.out.println("author Found successfully :"+author);
//			else System.out.println("author NOT Found :"+author);
	
//deleting the emp obj by calling dao layer method
		int noOfRecDel = authorDao.deleteAuthor(author.getAuthorId());
		if(noOfRecDel> 0) System.out.println("author Deleted successfully :"+author);
		else System.out.println("author NOT Deleted");
		
		
		noOfRecDel = authorDao.deleteBook(book.getIsbn());
		if(noOfRecDel> 0) System.out.println("book Deleted successfully :"+book);
		else System.out.println("book NOT Deleted");
	}
}
