package com.cg.demomap.service;

import java.util.HashMap;

import com.cg.demomap.dto.Department;
import com.cg.demomap.dto.Employee;
import com.cg.demomap.dto.Project;
import com.cg.demomap.exception.EmployeeException;

public interface EmployeeService {	
	public Employee<?,?> addEmployee(Employee<?,?> emp);
	public HashMap<?,?> showEmployee();
	public HashMap<?,?> showProject();
	public HashMap<?,?> showDepartment();
	public Project addProject(Project pro);
	public Department addDepartment(Department dep);
	}



