package com.cg.demomap.dto;

import java.util.HashMap;
import java.util.List;

public class Project {
	// one project can have Many employee 
	Integer projId;
	String projName;
	Double projCost;
	HashMap<?,Employee<?,?>> empList;
	public Project() {

	}
	
	public Project(Integer projId, String projName, Double projCost, HashMap<?, Employee<?, ?>> empList) {
		super();
		this.projId = projId;
		this.projName = projName;
		this.projCost = projCost;
		this.empList = empList;
	}
	public Integer getProjId() {
		return projId;
	}
	public void setProjId(Integer projId) {
		this.projId = projId;
	}
	public String getProjName() {
		return projName;
	}
	public void setProjName(String projName) {
		this.projName = projName;
	}
	public Double getProjCost() {
		return projCost;
	}
	public void setProjCost(Double projCost) {
		this.projCost = projCost;
	}
	public HashMap<?, Employee<?, ?>> getEmpList() {
		return empList;
	}
	public void setEmpList(HashMap<?, Employee<?, ?>> empList) {
		this.empList = empList;
	}
	

}