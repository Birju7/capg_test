package com.cg.demomap.dto;

import java.util.Comparator;

public class comparatorSal<T,K> implements Comparator<Employee<T,K>>{
	public int compare(Employee<T, K> o1, Employee<T, K> o) {
		// TODO Auto-generated method stub
		if((Double)o1.getEmpSalary()>(Double)o.getEmpSalary()) {
			return 1;
		}else if((Double)o1.getEmpSalary()<(Double)o.getEmpSalary()) {
			return -1;
		}
		return 0;


}
}
