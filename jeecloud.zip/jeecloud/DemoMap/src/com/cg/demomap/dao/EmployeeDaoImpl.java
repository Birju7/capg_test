package com.cg.demomap.dao;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;

import com.cg.demomap.dto.Department;
import com.cg.demomap.dto.Employee;
import com.cg.demomap.dto.Project;


public class EmployeeDaoImpl implements EmployeeDao{
		HashMap<Integer, Employee<?, ?>> myMap = new HashMap<Integer, Employee<?, ?>>();
		HashMap<Integer, Project> proj = new HashMap<Integer, Project>();
		HashMap<Integer, Department> depart = new HashMap<Integer, Department>();

		public Employee<?, ?> addEmployee(Employee<?,?> emp) {
			// TODO Auto-generated method stub
			myMap.put((Integer) emp.getEmpId(), emp);
			return emp;
		}
		public HashMap<?,?> showEmployee() {
			// TODO Auto-generated method stub
			return myMap;
		}
		@Override
		public Project addProject(Project pro) {
			// TODO Auto-generated method stub
			proj.put((Integer) pro.getProjId(), pro);
			return pro;
		}
		@Override
		public HashMap<?, ?> showProject() {
			// TODO Auto-generated method stub
			return proj;
		}
		@Override
		public Department addDepartment(Department dep) {
			// TODO Auto-generated method stub
			depart.put((Integer) dep.getDepId(), dep);
			return dep;
		}
		@Override
		public HashMap<?, ?> showDepartment() {
			// TODO Auto-generated method stub
			return depart;
		}
		

	}
