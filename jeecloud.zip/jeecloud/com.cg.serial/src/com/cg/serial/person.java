package com.cg.serial;

import java.io.File;
import java.io.OutputStream;
import java.io.Serializable;

public class person implements Serializable{


//	private static final long serialVersionUID = 1L;
	private static final long serialVersionUID = 7089577781092406L;
	String name;
	String add;
	String abc;
	public person(String name, String add, String abc) {
		super();
		this.name = name;
		this.add = add;
		this.abc = abc;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAdd() {
		return add;
	}
	public void setAdd(String add) {
		this.add = add;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	@Override
	public String toString() {
		return "person [name=" + name + ", add=" + add + ", abc=" + abc + "]";
	}

	
	

}
