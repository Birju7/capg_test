package com.cg.democollection.service;

public class emplo implements food, Manager{

	public void walk() {
		// TODO Auto-generated method stub
		System.out.println("In walk");
		
	}

	public void eat() {
		// TODO Auto-generated method stub
		System.out.println("In eat");
		
	}
	public void run() {
		System.out.println("run");
	}
	
	public static void main(String[] args) {
//		food obj = new emplo();
//		Manager o = new emplo();
//		emplo c = new emplo();
//		c.run();
//		c.eat();
//		c.walk();
		Integer a = 10*10*10;
		Integer b = 100*10;
		System.out.println(a==b);
		System.out.println(a.equals(b));
//		o.run();
//		obj.run();
//		o.eat();
//		obj.walk();
//		
	}
	

}
