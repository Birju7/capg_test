package com.cg.democollection.service;

public interface Manager {
public void walk();
}
