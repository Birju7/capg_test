package com.cg.democollection.service;


import java.util.LinkedList;
import java.util.List;
import org.omg.CORBA.PUBLIC_MEMBER;

import com.cg.democollection.dto.Employee;

public interface EmployeeService {
public Employee<Integer, Double> addEmployee(Employee<Integer, Double> emp);
public List<Employee<Integer, Double>> showEmployee();
}
