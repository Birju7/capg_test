package com.cg.demojunit.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.cg.demojunit.service.Calculatorservice;
import com.cg.demojunit.service.CalculatorserviceImpl;

public class CalculatorTest {
	Calculatorservice service;
	@Before
	public void beforeTest() {
		service = new CalculatorserviceImpl();
		System.out.println("Before Test");
		
	}
	@Test
	public void myTest() {
		assertEquals(new Double(30), service.addNumber(10.0, 20.0));
		assertEquals(new Double(20), service.subNumber(40.0, 20.0));
		assertEquals(new Double(8), service.mulNumber(4.0, 2.0));
		assertEquals(new Double(2), service.divNumber(4.0, 2.0));
	}
	@Test (expected=ArithmeticException.class)
	public void myTestException() {
		// TODO Auto-generated method stub
		service.divNumber(40.0, 0.0);

	}

	@After
	public void afterTest() {
		System.out.println("After Test");
		service = null;
	}
	
		
	
}
