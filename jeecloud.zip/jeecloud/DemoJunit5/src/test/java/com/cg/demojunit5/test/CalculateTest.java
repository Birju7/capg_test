package com.cg.demojunit5.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.demojunit5.service.CalculateService;
import com.cg.demojunit5.service.CalculateServiceImpl;
public class CalculateTest {


		CalculateService service;
		@BeforeEach
		public void beforeTest() {
			service = new CalculateServiceImpl();
			System.out.println("Before Test");
			
		}
		@Test
		public void myTest() {

			assertEquals(new Double(30), service.addNumber(10.0, 20.0));
			assertEquals(new Double(20), service.subNumber(40.0, 20.0));
			assertEquals(new Double(8), service.mulNumber(4.0, 2.0));
			assertEquals(new Double(2), service.divNumber(4.0, 2.0));
		}
		@Test 
		public void myTestException() {
			// TODO Auto-generated method stub
			assertThrows(ArithmeticException.class, ()->{service.divNumber(34, 0);});


		}

		@AfterEach
		public void afterTest() {
			System.out.println("After Test");
			service = null;
		}
		
			
		
	}

