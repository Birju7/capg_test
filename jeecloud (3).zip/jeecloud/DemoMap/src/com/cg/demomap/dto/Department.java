package com.cg.demomap.dto;

public class Department {
	private Integer depId;
	private String depName;
	private Employee<?, ?> depEmp;
	public Department() {
	}
	
	public Department(Integer depId, String depName, Employee<?, ?> depEmp) {
		super();
		this.depId = depId;
		this.depName = depName;
		this.depEmp = depEmp;
	}
	public Integer getDepId() {
		return depId;
	}
	public void setDepId(Integer depId) {
		this.depId = depId;
	}
	public String getDepName() {
		return depName;
	}
	public void setDepName(String depName) {
		this.depName = depName;
	}
	public Employee<?, ?> getDepEmp() {
		return depEmp;
	}
	public void setDepEmp(Employee<?, ?> depEmp) {
		this.depEmp = depEmp;
	}
	

}
