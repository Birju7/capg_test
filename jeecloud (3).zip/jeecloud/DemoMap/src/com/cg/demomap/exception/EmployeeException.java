package com.cg.demomap.exception;

public class EmployeeException extends Exception {
	public EmployeeException() {}
	public EmployeeException(String args) {
		super(args);
	}

}
