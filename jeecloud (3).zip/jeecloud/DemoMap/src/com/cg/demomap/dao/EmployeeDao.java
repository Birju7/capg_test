package com.cg.demomap.dao;

import java.util.HashMap;
import java.util.List;

import com.cg.demomap.dto.Department;
import com.cg.demomap.dto.Employee;
import com.cg.demomap.dto.Project;

public interface EmployeeDao {

	
	public Employee<?,?> addEmployee(Employee<?,?> emp);
	public HashMap<?,?> showEmployee();
	public HashMap<?,?> showProject();
	public HashMap<?,?> showDepartment();
	public Project addProject(Project pro);
	public Department addDepartment(Department dep);
	
	
	

}

