package com.cg.demomap.service;

import java.util.HashMap;
import java.util.List;

import com.cg.demomap.dao.EmployeeDaoImpl;
import com.cg.demomap.dto.Department;
import com.cg.demomap.dto.Employee;
import com.cg.demomap.dto.Project;
import com.cg.demomap.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService {
	
	EmployeeDaoImpl dao = new EmployeeDaoImpl();

	public Employee<?, ?> addEmployee(Employee<?, ?> emp) throws EmployeeException{
	
		if ((double)emp.getEmpSalary() <=0.0)
		{
			throw new EmployeeException("Sal cannot be less than 0");
		}
		return dao.addEmployee(emp);
	}

	public HashMap<?,?> showEmployee() {
		// TODO Auto-generated method stub
		return dao.showEmployee();
	}

	@Override
	public HashMap<?, ?> showProject() {
		// TODO Auto-generated method stub
		return dao.showProject();
	}

	@Override
	public HashMap<?, ?> showDepartment() {
		// TODO Auto-generated method stub
		return dao.showDepartment();
	}

	@Override
	public Project addProject(Project pro) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Department addDepartment(Department dep) {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
	
	

}


