package com.cg.lab3.model;

import java.math.BigDecimal;
import java.math.BigInteger;

public class Book {
	private BigInteger isbn;
	private String title;
	private BigDecimal price;
	private BigInteger book_author;
	
	public Book() {
	}
	
	public Book(BigInteger isbn, String title, BigDecimal price, BigInteger book_author) {
		super();
		this.isbn = isbn;
		this.title = title;
		this.price = price;
		this.book_author = book_author;
	}

	public BigInteger getBook_author() {
		return book_author;
	}

	public void setBook_author(BigInteger book_author) {
		this.book_author = book_author;
	}

	public BigInteger getIsbn() {
		return isbn;
	}
	public void setIsbn(BigInteger isbn) {
		this.isbn = isbn;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public BigDecimal getPrice() {
		return price;
	}
	public void setPrice(BigDecimal price) {
		this.price = price;
	}
	
	@Override
	public String toString() {
		return "Book [isbn=" + isbn + ", title=" + title + ", price=" + price + ", book_author=" + book_author + "]";
	}

	@Override
	public int hashCode() {
		return this.isbn.intValue();

	}
	@Override
	public boolean equals(Object obj) {
		return this.hashCode()== obj.hashCode();
	}
	
	
	
	
	
	

}
