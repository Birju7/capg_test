package com.cg.serial;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;

public class saving {
public static void main(String[] args) throws IOException {
	String name= "dsfsdf";
	File file = new File("C:\\Users\\admin\\Desktop\\New folder\\asd.txt");
	person per = new person("dsafkjdsaf", "dsfdsf");
	OutputStream oStream = new FileOutputStream(file);
	ObjectOutputStream outStream = new ObjectOutputStream(oStream);
	outStream.writeObject(per);
	outStream.close();
	oStream.close();
	System.out.println("Done");
	
	
	
}
}
