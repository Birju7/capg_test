package com.cg.serial;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.InputStream;

public class readi {
	public static void main(String[] args) throws IOException, ClassNotFoundException {
		File file = new File("C:\\Users\\admin\\Desktop\\New folder\\asd.txt");
		InputStream oStream = new FileInputStream(file);
		ObjectInputStream outStream = new ObjectInputStream(oStream);
		person per = (person)outStream.readObject();
		outStream.close();
		oStream.close();
		System.out.println(per);
		
		
		
	}

}
