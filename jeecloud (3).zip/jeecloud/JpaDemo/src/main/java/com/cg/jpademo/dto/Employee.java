package com.cg.jpademo.dto;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.Date;

import javax.persistence.*;

@Entity
@Table(name = "emp")
public class Employee {

	@Id
	@Column(name = "emp_id")
	private BigInteger empId;
	@Column(name = "emp_name")
	private String empName;
	@Column(name = "emp_salary")
	private BigDecimal empSalary;
	@Column(name = "date_of_joining")
	private Date dateOfJoining;
	@Embedded
	private Address empAddress;
	@OneToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE }, fetch = FetchType.EAGER)
	private Project empProject;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "dept_fk",nullable = false)
	private Department dept;

	public Employee() {
		// TODO Auto-generated constructor stub
	}

	public Employee(BigInteger empId, String empName, BigDecimal empSalary, Date dateOfJoining, Address empAddress,
			Project empProject, Department dept) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
		this.dateOfJoining = dateOfJoining;
		this.empAddress = empAddress;
		this.empProject = empProject;
		this.dept = dept;
	}

	public BigInteger getEmpId() {
		return empId;
	}

	public void setEmpId(BigInteger empId) {
		this.empId = empId;
	}

	public String getEmpName() {
		return empName;
	}

	public void setEmpName(String empName) {
		this.empName = empName;
	}

	public BigDecimal getEmpSalary() {
		return empSalary;
	}

	public void setEmpSalary(BigDecimal empSalary) {
		this.empSalary = empSalary;
	}

	public Date getDateOfJoining() {
		return dateOfJoining;
	}

	public void setDateOfJoining(Date dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}

	public Address getEmpAddress() {
		return empAddress;
	}

	public void setEmpAddress(Address empAddress) {
		this.empAddress = empAddress;
	}

	public Project getEmpProject() {
		return empProject;
	}

	public void setEmpProject(Project empProject) {
		this.empProject = empProject;
	}

	public Department getDept() {
		return dept;
	}

	public void setDept(Department dept) {
		this.dept = dept;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + ", dateOfJoining="
				+ dateOfJoining + ", empAddress=" + empAddress + ", empProject=" + empProject + ", dept=" + dept + "]";
	}

}
