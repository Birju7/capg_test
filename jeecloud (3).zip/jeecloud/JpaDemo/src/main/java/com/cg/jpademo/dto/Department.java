package com.cg.jpademo.dto;

import java.math.BigInteger;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Department {
	@Id
	private BigInteger deptId;
	private String deptname;
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL, mappedBy = "dept")
	private List<Employee> empList;

	public Department() {
		// TODO Auto-generated constructor stub
	}

	public Department(BigInteger deptId, String deptname, List<Employee> empList) {
		super();
		this.deptId = deptId;
		this.deptname = deptname;
		this.empList = empList;
	}

	public BigInteger getDeptId() {
		return deptId;
	}

	public void setDeptId(BigInteger deptId) {
		this.deptId = deptId;
	}

	public String getDeptname() {
		return deptname;
	}

	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}

	public List<Employee> getEmpList() {
		return empList;
	}

	public void setEmpList(List<Employee> empList) {
		this.empList = empList;
	}

	@Override
	public String toString() {
		return "Department [deptId=" + deptId + ", deptname=" + deptname + "]";
	}

}
