package com.cg.employeemanagement.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class HotelManagementTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
