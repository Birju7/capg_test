package com.cg.democollection.dao;

import java.util.LinkedList;
import java.util.List;

import com.cg.democollection.dto.Employee;

public interface EmployeeDao {
	//Crud
	public Employee<Integer, Double> addEmployee(Employee<Integer, Double> emp);
	public List<Employee<Integer, Double>> showEmployee();
	
	

}
