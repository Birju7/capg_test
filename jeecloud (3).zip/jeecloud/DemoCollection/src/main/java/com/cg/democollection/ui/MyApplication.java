package com.cg.democollection.ui;

import java.util.List;
import java.util.Scanner;
import java.util.Set;
import java.util.Timer;
import java.util.TreeSet;
import java.security.Provider.Service;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import com.cg.democollection.dto.Employee;
import com.cg.democollection.dto.comparatorSal;
import com.cg.democollection.service.EmployeeService;
import com.cg.democollection.service.EmployeeServiceImpl;

//Difference between array and arraylist and vector
//Difference between array list and linked list 
// how when and what to use



public class MyApplication {
	public static void printDetail() {
		System.out.println("1 for Add");
		System.out.println("2 for show");
	}
	
	public static void main(String[] args) {
		int choice;
//		List<Employee<Integer, Double>> myList = new LinkedList<Employee<Integer, Double>>();
		EmployeeServiceImpl service = new EmployeeServiceImpl();
		Scanner sc = new Scanner(System.in);
		do {
//			double start_time = Timer
			printDetail();
			choice = sc.nextInt();
			switch (choice) {
			case 1:
			System.out.println("Enter the id");
			Integer id = sc.nextInt();
			System.out.println("Enter the name");
			String name = sc.next();
			System.out.println("Enter the salary");
			Double sal = sc.nextDouble();
			Employee<Integer, Double> emp = new Employee<Integer, Double>();
			emp.setEmpId(id);
			emp.setEmpName(name);
			emp.setEmpSalary(sal);
			service.addEmployee(emp);
			
	
				
				break;

			case 2:
				List<Employee<Integer, Double>> myList = service.showEmployee();
				Collections.sort(myList, new Employee<Integer, Double>());
				Collections.sort(myList, new comparatorSal());
				for (Employee<Integer, Double> employee : myList) {
					System.out.println("ID"+employee.getEmpId());
					System.out.println("Name"+employee.getEmpName());
					System.out.println("Salary"+employee.getEmpSalary());
				}
				break;
				
			}
		} while (choice !=3);
		sc.close();
		
		
//		List<Employee<Integer, Double>> myList = new LinkedList<Employee<Integer, Double>>();
//		myList.add(1);
//		myList.add(7);
//		myList.add(4);
//		myList.add(7);
//		System.out.println(myList.size());
//		for (Integer integer : myList) {
//			System.out.println(integer);
//		}
//		for (int i = 0; i < myList.size(); i++) {
//			System.out.println(myList.get(i));
//		}
//		System.out.println(myList.indexOf(4));
//		System.out.println(myList.lastIndexOf(7));
		
		
		
		
//		Employee<int, Double> emp = new Employee<int, Double>(1001,"A", 11.1);
//		try {
//			emp.name(213.0);
//		} catch (Exception e) {
//			System.out.println(e.getMessage());
//		}
//		
		
		
		
//		Set<String> mySet = new TreeSet<String>();
//		mySet.add("4");
//		mySet.add("5");
//		mySet.add();
//		System.out.println(mySet);
		
		
//		Set <Empl	oyee<Integer, Double>> mySet = new TreeSet<Employee<Integer, Double>>();
//		Employee<Integer, Double> empOne = new Employee<Integer, Double>(1001,"A", 11.1);
//		Employee<Integer, Double> empTwo = new Employee<Integer, Double>(101,"A", 11.1);
//		mySet.add(empTwo);
//		if(empOne.equals(empTwo))
//			System.out.println("True");
//		mySet.add(empOne);
//		for (Employee<Integer, Double> employee : mySet) {
//			
//			System.out.println(employee.getEmpId());
//		}
		
//		Employee<Integer, Double> empOne = new Employee<Integer, Double>();
//		empOne.setEmpId(1001);
//		Employee<String, Double> empTwo = new Employee<String, Double>();
//		empTwo.setEmpId("12");
//		System.out.println(empOne.name(67.0));
//		List <? extends Number>ls  = new ArrayList<Integer>();
//		Set<String> mySet = new HashSet<String>();
//		mySet.add("aac");
//		mySet.add("aca");
//		mySet.add("a");
//		mySet.add("h");
//		mySet.add("a");
//		mySet.add("G");
//		mySet.add("g");
//		mySet.add("A");
//		mySet.add("$");
//		mySet.add("/");
//		mySet.add(" ");
//		mySet.add("$]");
//		mySet.add("zz");
//		mySet.add("Z");
//		mySet.add("1");
//		mySet.add("0");
//		mySet.add("9");
//		mySet.add("]");
		
//		System.out.println(mySet);
//		System.out.println(mySet.size());
//		System.out.println(mySet.hashCode());
//		System.out.println(mySet.toArray()[7]);
//		Iterator<String > it = mySet.iterator();
//		while (it.hasNext()) {
//			System.out.println(it.next());
//			
//		}
		
		
		
		
		
	}
	
	

}
