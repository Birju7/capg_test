package com.cg.democollection.dto;

import java.util.Comparator;

//public class Employee<T,K> implements Comparator<Employee<T,K>
public class comparatorSal<T,K> implements Comparator<Employee<T,K>>{
	public int compare(Employee<T, K> o1, Employee<T, K> o) {
		// TODO Auto-generated method stub
		if((Integer)o1.getEmpId()>(Integer)o.getEmpId()) {
		return 1;
	}else if((Integer)o1.getEmpId()<(Integer)o.getEmpId()) {
		return -1;
	}
	return 0;
	}
	
	

}
