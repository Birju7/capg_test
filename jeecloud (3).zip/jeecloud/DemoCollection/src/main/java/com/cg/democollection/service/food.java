package com.cg.democollection.service;

public interface food {
public void eat();
}
