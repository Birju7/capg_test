package com.cg.demojunit5.service;

public  interface CalculateService {
	 public Double addNumber(double numOne, double numTwo);
	 public Double subNumber(double numOne, double numTwo);
	 public Double mulNumber(double numOne, double numTwo);
	 public Double divNumber(double numOne, double numTwo);
	}
